﻿using System;
namespace leap_year
{
    class Program
    {
        static void Main(string[] args)
        {
            int sayac = 0;
            DateTime date = DateTime.Now;
            for (int i = 1901; i <= 2000; i++)
            {
                for(int j = 1; j <= 12; j++)
                {
                     date = new DateTime(i, j, 1);
                    if (date.DayOfWeek.ToString() == "Thursday")
                        sayac++;
                }
            }
            Console.Write(sayac);
            Console.Read();
        }
    }
}
